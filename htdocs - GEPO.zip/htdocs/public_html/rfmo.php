<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success Stories & Partnerships</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Swiper.js CSS & JS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
</head>
<body class="bg-gray-100">

<section class="container mx-auto p-6">
    <!-- Section Title -->
    <h2 class="text-3xl font-bold text-center mb-6">🏆 Success Stories</h2>

    <!-- Swiper Carousel -->
    <div class="swiper mySwiper overflow-hidden">
        <div class="swiper-wrapper">
            <!-- Card 1 -->
            <div class="swiper-slide bg-white shadow-lg rounded-lg p-4 transition-transform transform hover:scale-105 hover:shadow-2xl">
                <img src="success1.jpg" class="w-full h-40 object-cover rounded-md" alt="Story 1">
                <h3 class="text-lg font-semibold mt-3">Collaboration with XYZ University</h3>
                <p class="text-sm text-gray-600">Impactful research in AI and sustainability.</p>
            </div>
        </div>
        <!-- Swiper Pagination & Navigation -->
        <div class="swiper-pagination"></div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
    </div>
</section>

<!-- RFMO Section -->
<section class="container mx-auto p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
    <!-- Left Column: Seed Funding & Evaluation -->
    <div class="bg-white shadow-lg rounded-lg p-6">
        <h2 class="text-2xl font-bold mb-4">💰 Seed Funding & Evaluation</h2>
        <ul class="list-disc pl-4 space-y-2 text-gray-700">
            <li>Eligibility Criteria</li>
            <li>Application Process</li>
            <li>Evaluation Metrics</li>
            <li>Approval Timeline</li>
        </ul>
    </div>

    <!-- Middle Column: Quarterly Evaluation Guidelines -->
    <div class="bg-white shadow-lg rounded-lg p-6">
        <h2 class="text-2xl font-bold mb-4">📊 Quarterly Evaluation</h2>
        <div class="space-y-3">
            <details class="p-3 border rounded-md cursor-pointer">
                <summary class="font-semibold">Evaluation Metrics</summary>
                <p class="text-sm mt-2">Criteria used to assess project progress.</p>
            </details>
            <details class="p-3 border rounded-md cursor-pointer">
                <summary class="font-semibold">Reporting Deadlines</summary>
                <p class="text-sm mt-2">Quarterly submissions and review dates.</p>
            </details>
        </div>
        <a href="#" class="block mt-4 text-blue-600 hover:underline">📄 Download Guidelines PDF</a>
    </div>

    <!-- Right Column: Submission Forms -->
    <div class="bg-white shadow-lg rounded-lg p-6">
        <h2 class="text-2xl font-bold mb-4">📝 Submission Forms</h2>
        <form>
            <label class="block mb-2">Project Name</label>
            <input type="text" class="w-full border p-2 rounded-md mb-4" placeholder="Enter Project Name" required>
            
            <label class="block mb-2">Organization</label>
            <input type="text" class="w-full border p-2 rounded-md mb-4" placeholder="Your Organization" required>
            
            <label class="block mb-2">Upload Proposal</label>
            <input type="file" class="w-full border p-2 rounded-md mb-4" required>
            
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Submit Proposal</button>
        </form>
    </div>
</section>

<!-- Swiper.js Initialization -->
<script>
    var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        spaceBetween: 20,
        loop: true,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        breakpoints: {
            640: { slidesPerView: 2 },
            1024: { slidesPerView: 3 }
        },
    });
</script>

</body>
</html>
