<?php
// Start session and include database connection if needed
session_start();

// Example: Include database connection file
// include 'db_connection.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Global Partnerships</title>
    <link rel="stylesheet" href="styles/globalpartnerstyles.css">
    <?php include 'assets/phppages/headernav.php'; ?>
</head>
<body>

    <main class="global-partnerships">
        <h2>Global Partnerships</h2>

        <!-- Interactive Map Section -->
        <div class="map">
            <h3>Our Global Partners</h3>
            <img src="world_map.png" alt="Interactive Map of Partners">
        </div>

        <!-- Success Stories Section -->
        <div class="success-stories">
            <h3>Success Stories</h3>
            <div class="story">
                <img src="partner1.jpg" alt="Partner 1">
                <div class="story-content">
                    <h3>Partnering for Innovation</h3>
                    <p>Collaboration with XYZ University led to groundbreaking research in renewable energy.</p>
                </div>
            </div>

            <div class="story">
                <img src="partner2.jpg" alt="Partner 2">
                <div class="story-content">
                    <h3>Expanding Opportunities</h3>
                    <p>Our partnership with ABC Corporation created 50 internship opportunities for students.</p>
                </div>
            </div>
        </div>

        <!-- Partnership Inquiry Form Section -->
        <div class="inquiry-form">
            <h3>Partnership Inquiry Form</h3>
            <form action="submit_inquiry.php" method="POST">
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <input type="text" name="organization" placeholder="Your Organization" required>
                <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
                <button type="submit">Submit Inquiry</button>
            </form>
        </div>
    </main>
</body>
<?php include 'assets/phppages/footer.php'; ?>
</html>
