
<?php
// events_news_page.php

// Start the session and include necessary libraries if needed
session_start();

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events & News Hub</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to CSS -->
    <!-- Add libraries for Bootstrap or jQuery if needed -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Header Section -->
    <header>
        <h1>Events & News Hub</h1>
        <p>Stay updated with the latest happenings, achievements, and upcoming events around the globe.</p>
        <nav>
            <a href="#calendar">Calendar</a>
            <a href="#news">News</a>
            <a href="#gallery">Gallery</a>
            <a href="#social">Social Media</a>
        </nav>
    </header>

    <!-- Calendar Section -->
    <section id="calendar">
        <h2>Upcoming Events</h2>
        <div class="calendar-container">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search Events">
                <button type="submit">Search</button>
            </form>

            <div class="event-list">
                <?php
                // Dummy events (replace with database logic)
                $events = [
                    ['title' => 'Webinar on AI', 'date' => '2025-02-01', 'location' => 'Online'],
                    ['title' => 'Global Conference on Education', 'date' => '2025-03-15', 'location' => 'New York'],
                ];

                foreach ($events as $event) {
                    echo "<div class='event'>
                            <h3>{$event['title']}</h3>
                            <p>Date: {$event['date']}</p>
                            <p>Location: {$event['location']}</p>
                            <a href='#'>Register Now</a>
                          </div>";
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Latest News Section -->
    <section id="news">
        <h2>Latest News</h2>
        <div class="news-container">
            <?php
            // Dummy news data (replace with database logic)
            $news = [
                ['title' => 'New Scholarship Program Launched', 'summary' => 'We are excited to announce...', 'link' => '#'],
                ['title' => 'Partnership with XYZ', 'summary' => 'A new collaboration with XYZ...', 'link' => '#']
            ];

            foreach ($news as $item) {
                echo "<div class='news-item'>
                        <h3>{$item['title']}</h3>
                        <p>{$item['summary']}</p>
                        <a href='{$item['link']}'>Read More</a>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Photo and Video Galleries Section -->
    <section id="gallery">
        <h2>Gallery</h2>
        <div class="photo-gallery">
            <h3>Photos</h3>
            <?php
            // Dummy photo links (replace with actual photo paths)
            $photos = ['photo1.jpg', 'photo2.jpg', 'photo3.jpg'];

            foreach ($photos as $photo) {
                echo "<img src='images/$photo' alt='Event Photo' class='gallery-photo'>";
            }
            ?>
        </div>
        <div class="video-gallery">
            <h3>Videos</h3>
            <?php
            // Dummy video links (replace with actual video URLs)
            $videos = ['https://www.youtube.com/embed/video1', 'https://www.youtube.com/embed/video2'];

            foreach ($videos as $video) {
                echo "<iframe src='$video' frameborder='0' allowfullscreen class='gallery-video'></iframe>";
            }
            ?>
        </div>
    </section>

    <!-- Social Media Feed Section -->
    <section id="social">
        <h2>Social Media</h2>
        <div class="social-feed">
            <p>Follow us on:</p>
            <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i> Twitter</a>
            <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin"></i> LinkedIn</a>
            <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook"></i> Facebook</a>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <p>&copy; 2025 Events & News Hub. All Rights Reserved.</p>
        <nav>
            <a href="#">About</a>
            <a href="#">Contact</a>
            <a href="#">Privacy Policy</a>
        </nav>
    </footer>
</body>
</html><?php
// events_news_page.php

// Start the session and include necessary libraries if needed
session_start();

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events & News Hub</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to CSS -->
    <!-- Add libraries for Bootstrap or jQuery if needed -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Header Section -->
    <header>
        <h1>Events & News Hub</h1>
        <p>Stay updated with the latest happenings, achievements, and upcoming events around the globe.</p>
        <nav>
            <a href="#calendar">Calendar</a>
            <a href="#news">News</a>
            <a href="#gallery">Gallery</a>
            <a href="#social">Social Media</a>
        </nav>
    </header>

    <!-- Calendar Section -->
    <section id="calendar">
        <h2>Upcoming Events</h2>
        <div class="calendar-container">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search Events">
                <button type="submit">Search</button>
            </form>

            <div class="event-list">
                <?php
                // Dummy events (replace with database logic)
                $events = [
                    ['title' => 'Webinar on AI', 'date' => '2025-02-01', 'location' => 'Online'],
                    ['title' => 'Global Conference on Education', 'date' => '2025-03-15', 'location' => 'New York'],
                ];

                foreach ($events as $event) {
                    echo "<div class='event'>
                            <h3>{$event['title']}</h3>
                            <p>Date: {$event['date']}</p>
                            <p>Location: {$event['location']}</p>
                            <a href='#'>Register Now</a>
                          </div>";
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Latest News Section -->
    <section id="news">
        <h2>Latest News</h2>
        <div class="news-container">
            <?php
            // Dummy news data (replace with database logic)
            $news = [
                ['title' => 'New Scholarship Program Launched', 'summary' => 'We are excited to announce...', 'link' => '#'],
                ['title' => 'Partnership with XYZ', 'summary' => 'A new collaboration with XYZ...', 'link' => '#']
            ];

            foreach ($news as $item) {
                echo "<div class='news-item'>
                        <h3>{$item['title']}</h3>
                        <p>{$item['summary']}</p>
                        <a href='{$item['link']}'>Read More</a>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Photo and Video Galleries Section -->
    <section id="gallery">
        <h2>Gallery</h2>
        <div class="photo-gallery">
            <h3>Photos</h3>
            <?php
            // Dummy photo links (replace with actual photo paths)
            $photos = ['photo1.jpg', 'photo2.jpg', 'photo3.jpg'];

            foreach ($photos as $photo) {
                echo "<img src='images/$photo' alt='Event Photo' class='gallery-photo'>";
            }
            ?>
        </div>
        <div class="video-gallery">
            <h3>Videos</h3>
            <?php
            // Dummy video links (replace with actual video URLs)
            $videos = ['https://www.youtube.com/embed/video1', 'https://www.youtube.com/embed/video2'];

            foreach ($videos as $video) {
                echo "<iframe src='$video' frameborder='0' allowfullscreen class='gallery-video'></iframe>";
            }
            ?>
        </div>
    </section>

    <!-- Social Media Feed Section -->
    <section id="social">
        <h2>Social Media</h2>
        <div class="social-feed">
            <p>Follow us on:</p>
            <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i> Twitter</a>
            <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin"></i> LinkedIn</a>
            <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook"></i> Facebook</a>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <p>&copy; 2025 Events & News Hub. All Rights Reserved.</p>
        <nav>
            <a href="#">About</a>
            <a href="#">Contact</a>
            <a href="#">Privacy Policy</a>
        </nav>
    </footer>
</body>
</html>
















Here’s the updated version of your PHP code with embedded CSS styling. I've added a `<style>` tag within the `<head>` section to keep all styles in the same file, adhering to your request not to remove any PHP code:

```php
<?php
// events_news_page.php

// Start the session and include necessary libraries if needed
session_start();

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events & News Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ffffff; /* White main background color */
            color: #333; /* Default text color */
        }

        a {
            text-decoration: none;
            color: #0056b3; /* Blue for links */
        }

        a:hover {
            text-decoration: underline;
        }

        /* Header Styles */
        header {
            background-color: #2e8b57; /* Sea green for header */
            color: white;
            padding: 20px;
            text-align: center;
        }

        header nav a {
            margin: 0 10px;
            color: white;
            font-weight: bold;
        }

        header nav a:hover {
            text-decoration: underline;
        }

        /* Footer Styles */
        footer {
            background-color: #2e8b57; /* Sea green for footer */
            color: white;
            padding: 10px;
            text-align: center;
        }

        footer nav a {
            margin: 0 5px;
            color: white;
        }

        /* Section Styles */
        section {
            padding: 20px;
            margin: 20px auto;
            max-width: 900px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        #calendar, #news, #gallery, #social {
            background-color: #f9f9f9; /* Slightly off-white for sections */
        }

        h2 {
            border-bottom: 2px solid #2e8b57;
            padding-bottom: 10px;
        }

        /* Buttons */
        button, .event a, .news-item a {
            display: inline-block;
            background-color: #0056b3; /* Blue for buttons */
            color: white;
            padding: 8px 15px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover, .event a:hover, .news-item a:hover {
            background-color: #003d80; /* Darker blue on hover */
        }

        /* Calendar Styles */
        .calendar-container {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .event-list .event {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            margin: 10px 0;
            background-color: white;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        /* News Styles */
        .news-container .news-item {
            margin: 15px 0;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: white;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        /* Gallery Styles */
        .photo-gallery, .video-gallery {
            margin: 20px 0;
        }

        .gallery-photo {
            width: 100px;
            height: 100px;
            margin: 5px;
            border-radius: 8px;
            object-fit: cover;
        }

        .gallery-video {
            width: 100%;
            max-width: 400px;
            height: 200px;
            margin: 10px 0;
        }

        /* Social Media Styles */
        .social-feed a {
            display: inline-block;
            margin: 10px 5px;
            color: #2e8b57;
            font-size: 20px;
        }

        .social-feed a:hover {
            color: #0056b3; /* Blue on hover */
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <header>
        <h1>Events & News Hub</h1>
        <p>Stay updated with the latest happenings, achievements, and upcoming events around the globe.</p>
        <nav>
            <a href="#calendar">Calendar</a>
            <a href="#news">News</a>
            <a href="#gallery">Gallery</a>
            <a href="#social">Social Media</a>
        </nav>
    </header>

    <!-- Calendar Section -->
    <section id="calendar">
        <h2>Upcoming Events</h2>
        <div class="calendar-container">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search Events">
                <button type="submit">Search</button>
            </form>

            <div class="event-list">
                <?php
                // Dummy events (replace with database logic)
                $events = [
                    ['title' => 'Webinar on AI', 'date' => '2025-02-01', 'location' => 'Online'],
                    ['title' => 'Global Conference on Education', 'date' => '2025-03-15', 'location' => 'New York'],
                ];

                foreach ($events as $event) {
                    echo "<div class='event'>
                            <h3>{$event['title']}</h3>
                            <p>Date: {$event['date']}</p>
                            <p>Location: {$event['location']}</p>
                            <a href='#'>Register Now</a>
                          </div>";
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Latest News Section -->
    <section id="news">
        <h2>Latest News</h2>
        <div class="news-container">
            <?php
            // Dummy news data (replace with database logic)
            $news = [
                ['title' => 'New Scholarship Program Launched', 'summary' => 'We are excited to announce...', 'link' => '#'],
                ['title' => 'Partnership with XYZ', 'summary' => 'A new collaboration with XYZ...', 'link' => '#']
            ];

            foreach ($news as $item) {
                echo "<div class='news-item'>
                        <h3>{$item['title']}</h3>
                        <p>{$item['summary']}</p>
                        <a href='{$item['link']}'>Read More</a>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Photo and Video Galleries Section -->
    <section id="gallery">
        <h2>Gallery</h2>
        <div class="photo-gallery">
            <h3>Photos</h3>
            <?php
            // Dummy photo links (replace with actual photo paths)
            $photos = ['photo1.jpg', 'photo2.jpg', 'photo3.jpg'];

            foreach ($photos as $photo) {
                echo "<img src='images/$photo' alt='Event Photo' class='gallery-photo'>";
            }
            ?>
        </div>
        <div class="video-gallery">
            <h3>Videos</h3>
            <?php
            // Dummy video links (replace with actual video URLs)
            $videos = ['https://www.youtube.com/embed/video1', 'https://www.youtube.com/embed/video2'];

            foreach ($videos as $video) {
                echo "<iframe src='$video' frameborder='0' allowfullscreen class='gallery-video'></iframe>";
            }
            ?>
        </div>
    </section>

    <!-- Social Media Feed Section -->
    <section id="social">
        <h2>Social Media</h2>
        <div class="social-feed">
            <p>Follow us on:</p>
            <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i> Twitter</a>
            <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin"></i> LinkedIn</a>
            <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook"></i> Facebook</a>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <p>&copy; 2025 Events & News Hub. All Rights Reserved.</p>
        <nav>
            <a href="#">About</a>
            <a href="#">Contact</a>
            <a href="#">Privacy Policy</a>
        </nav>
    </footer>
</body>
</html>
```








<?php
// events_news_page.php

// Start the session and include necessary libraries if needed
session_start();
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events & News Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: white;
            color: #333;
        }

        /* Header */
        header {
            background-color: #2E8B57; /* Sea Green */
            color: white;
            text-align: center;
            padding: 20px;
        }

        nav {
            margin-top: 10px;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-weight: bold;
        }

        /* Sections */
        section {
            padding: 20px;
            text-align: center;
        }

        h2 {
            color: #2E8B57;
        }

        /* Buttons */
        button, a {
            background-color: #007BFF; /* Blue */
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
        }

        button:hover, a:hover {
            background-color: #0056b3;
        }

        /* Calendar and Events */
        .calendar-container {
            background: #f8f8f8;
            padding: 20px;
            border-radius: 10px;
        }

        .event {
            background: white;
            padding: 15px;
            margin: 10px;
            border-radius: 5px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
        }

        /* News Section */
        .news-container {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .news-item {
            background: white;
            width: 80%;
            padding: 15px;
            margin: 10px;
            border-radius: 5px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
        }

        /* Gallery */
        .gallery-photo {
            width: 150px;
            height: 100px;
            margin: 10px;
            border-radius: 5px;
        }

        .gallery-video {
            width: 300px;
            height: 200px;
            margin: 10px;
        }

        /* Social Media */
        .social-feed {
            text-align: center;
        }

        .social-feed a {
            margin: 10px;
        }

        /* Footer */
        footer {
            background-color: #2E8B57; /* Sea Green */
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 20px;
        }

        footer a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
        }

    </style>
</head>
<body>

    <!-- Header Section -->
    <header>
        <h1>Events & News Hub</h1>
        <p>Stay updated with the latest happenings, achievements, and upcoming events around the globe.</p>
        <nav>
            <a href="#calendar">Calendar</a>
            <a href="#news">News</a>
            <a href="#gallery">Gallery</a>
            <a href="#social">Social Media</a>
        </nav>
    </header>

    <!-- Calendar Section -->
    <section id="calendar">
        <h2>Upcoming Events</h2>
        <div class="calendar-container">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search Events">
                <button type="submit">Search</button>
            </form>

            <div class="event-list">
                <?php
                $events = [
                    ['title' => 'Webinar on AI', 'date' => '2025-02-01', 'location' => 'Online'],
                    ['title' => 'Global Conference on Education', 'date' => '2025-03-15', 'location' => 'New York'],
                ];

                foreach ($events as $event) {
                    echo "<div class='event'>
                            <h3>{$event['title']}</h3>
                            <p>Date: {$event['date']}</p>
                            <p>Location: {$event['location']}</p>
                            <a href='#'>Register Now</a>
                          </div>";
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Latest News Section -->
    <section id="news">
        <h2>Latest News</h2>
        <div class="news-container">
            <?php
            $news = [
                ['title' => 'New Scholarship Program Launched', 'summary' => 'We are excited to announce...', 'link' => '#'],
                ['title' => 'Partnership with XYZ', 'summary' => 'A new collaboration with XYZ...', 'link' => '#']
            ];

            foreach ($news as $item) {
                echo "<div class='news-item'>
                        <h3>{$item['title']}</h3>
                        <p>{$item['summary']}</p>
                        <a href='{$item['link']}'>Read More</a>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Photo and Video Galleries Section -->
    <section id="gallery">
        <h2>Gallery</h2>
        <div class="photo-gallery">
            <h3>Photos</h3>
            <?php
            $photos = ['photo1.jpg', 'photo2.jpg', 'photo3.jpg'];

            foreach ($photos as $photo) {
                echo "<img src='images/$photo' alt='Event Photo' class='gallery-photo'>";
            }
            ?>
        </div>
        <div class="video-gallery">
            <h3>Videos</h3>
            <?php
            $videos = ['https://www.youtube.com/embed/video1', 'https://www.youtube.com/embed/video2'];

            foreach ($videos as $video) {
                echo "<iframe src='$video' frameborder='0' allowfullscreen class='gallery-video'></iframe>";
            }
            ?>
        </div>
    </section>

    <!-- Social Media Feed Section -->
    <section id="social">
        <h2>Social Media</h2>
        <div class="social-feed">
            <p>Follow us on:</p>
            <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i> Twitter</a>
            <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin"></i> LinkedIn</a>
            <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook"></i> Facebook</a>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <p>&copy; 2025 Events & News Hub. All Rights Reserved.</p>
        <nav>
            <a href="#">About</a>
            <a href="#">Contact</a>
            <a href="#">Privacy Policy</a>
        </nav>
    </footer>

</body>
</html>














<?php
// events_news_page.php

// Start the session and include necessary libraries if needed
session_start();
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Events & News Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* General Styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        /* Header */
        header {
            background-color: #2E8B57; /* Sea Green */
            color: white;
            text-align: center;
            padding: 30px 15px;
            font-size: 22px;
            font-weight: bold;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        nav {
            margin-top: 10px;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-weight: bold;
            padding: 10px 15px;
            transition: 0.3s;
        }

        nav a:hover {
            background-color: #1d6b3b;
            border-radius: 5px;
        }

        /* Sections */
        section {
            padding: 40px 10%;
            text-align: center;
            background-color: white;
            margin: 20px auto;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h2 {
            color: #2E8B57;
            font-size: 26px;
            border-bottom: 3px solid #2E8B57;
            display: inline-block;
            padding-bottom: 5px;
            margin-bottom: 20px;
        }

        /* Buttons */
        button, a.button {
            background-color: #007BFF; /* Blue */
            color: white;
            padding: 12px 20px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            transition: 0.3s;
            display: inline-block;
            margin-top: 15px;
        }

        button:hover, a.button:hover {
            background-color: #0056b3;
        }

        /* Calendar and Events */
        .calendar-container {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
        }

        .event {
            background: white;
            padding: 20px;
            margin: 15px auto;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            text-align: left;
            max-width: 500px;
        }

        .event h3 {
            color: #007BFF;
        }

        /* News Section */
        .news-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .news-item {
            background: white;
            width: 45%;
            padding: 20px;
            margin: 15px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            text-align: left;
        }

        /* Gallery */
        .gallery-photo {
            width: 180px;
            height: 120px;
            margin: 15px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .gallery-video {
            width: 320px;
            height: 200px;
            margin: 15px;
            border-radius: 8px;
        }

        /* Social Media */
        .social-feed {
            text-align: center;
        }

        .social-feed a {
            margin: 15px;
            font-size: 18px;
            text-decoration: none;
            color: #007BFF;
            transition: 0.3s;
        }

        .social-feed a:hover {
            color: #0056b3;
        }

        /* Footer */
        footer {
            background-color: #2E8B57; /* Sea Green */
            color: white;
            text-align: center;
            padding: 20px;
            font-size: 14px;
            margin-top: 30px;
        }

        footer a {
            color: white;
            text-decoration: none;
            margin: 0 12px;
            font-weight: bold;
        }

    </style>
</head>
<body>

    <!-- Header Section -->
    <header>
        <h1>College Events & News Hub</h1>
        <p>Stay updated with the latest happenings, achievements, and upcoming events at our college.</p>
        <nav>
            <a href="#calendar">Calendar</a>
            <a href="#news">News</a>
            <a href="#gallery">Gallery</a>
            <a href="#social">Social Media</a>
        </nav>
    </header>

    <!-- Calendar Section -->
    <section id="calendar">
        <h2>Upcoming Events</h2>
        <div class="calendar-container">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search Events">
                <button type="submit">Search</button>
            </form>

            <div class="event-list">
                <?php
                $events = [
                    ['title' => 'Webinar on AI', 'date' => '2025-02-01', 'location' => 'Online'],
                    ['title' => 'Global Conference on Education', 'date' => '2025-03-15', 'location' => 'New York'],
                ];

                foreach ($events as $event) {
                    echo "<div class='event'>
                            <h3>{$event['title']}</h3>
                            <p>Date: {$event['date']}</p>
                            <p>Location: {$event['location']}</p>
                            <a href='#' class='button'>Register Now</a>
                          </div>";
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Latest News Section -->
    <section id="news">
        <h2>Latest News</h2>
        <div class="news-container">
            <?php
            $news = [
                ['title' => 'New Scholarship Program Launched', 'summary' => 'We are excited to announce...', 'link' => '#'],
                ['title' => 'Partnership with XYZ', 'summary' => 'A new collaboration with XYZ...', 'link' => '#']
            ];

            foreach ($news as $item) {
                echo "<div class='news-item'>
                        <h3>{$item['title']}</h3>
                        <p>{$item['summary']}</p>
                        <a href='{$item['link']}' class='button'>Read More</a>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <p>&copy; 2025 College Events & News Hub. All Rights Reserved.</p>
        <nav>
            <a href="#">About</a>
            <a href="#">Contact</a>
            <a href="#">Privacy Policy</a>
        </nav>
    </footer>

</body>
</html>

















<?php
// events_news_page.php

// Start the session and include necessary libraries if needed
session_start();
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Events & News Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* General Styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        /* Header */
        header {
            background-color: #2E8B57; /* Sea Green */
            color: white;
            text-align: center;
            padding: 30px 15px;
            font-size: 22px;
            font-weight: bold;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        nav {
            margin-top: 10px;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-weight: bold;
            padding: 10px 15px;
            transition: 0.3s;
        }

        nav a:hover {
            background-color: #1d6b3b;
            border-radius: 5px;
        }

        /* Sections */
        section {
            padding: 40px 10%;
            text-align: center;
            background-color: white;
            margin: 20px auto;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h2 {
            color: #2E8B57;
            font-size: 26px;
            border-bottom: 3px solid #2E8B57;
            display: inline-block;
            padding-bottom: 5px;
            margin-bottom: 20px;
        }

        /* Buttons */
        button, a.button {
            background-color: #B2B2B2; /* Ash Color */
            color: white;
            padding: 12px 20px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            transition: 0.3s;
            display: inline-block;
            margin-top: 15px;
        }

        button:hover, a.button:hover {
            background-color: #8C8C8C; /* Darker Ash Color */
        }

        /* Calendar and Events */
        .calendar-container {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
        }

        .event {
            background: white;
            padding: 20px;
            margin: 15px auto;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            text-align: left;
            max-width: 500px;
        }

        .event h3 {
            color: #007BFF;
        }

        /* News Section */
        .news-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .news-item {
            background: white;
            width: 45%;
            padding: 20px;
            margin: 15px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            text-align: left;
        }

        /* Gallery */
        .gallery-photo {
            width: 180px;
            height: 120px;
            margin: 15px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .gallery-video {
            width: 320px;
            height: 200px;
            margin: 15px;
            border-radius: 8px;
        }

        /* Social Media */
        .social-feed {
            text-align: center;
        }

        .social-feed a {
            margin: 15px;
            font-size: 18px;
            text-decoration: none;
            color: #007BFF;
            transition: 0.3s;
        }

        .social-feed a:hover {
            color: #0056b3;
        }

        /* Footer */
        footer {
            background-color: #2E8B57; /* Sea Green */
            color: white;
            text-align: center;
            padding: 20px;
            font-size: 14px;
            margin-top: 30px;
        }

        footer a {
            color: white;
            text-decoration: none;
            margin: 0 12px;
            font-weight: bold;
        }

    </style>
</head>
<body>

    <!-- Header Section -->
    <header>
        <h1>College Events & News Hub</h1>
        <p>Stay updated with the latest happenings, achievements, and upcoming events at our college.</p>
        <nav>
            <a href="#calendar">Calendar</a>
            <a href="#news">News</a>
            <a href="#gallery">Gallery</a>
            <a href="#social">Social Media</a>
        </nav>
    </header>

    <!-- Calendar Section -->
    <section id="calendar">
        <h2>Upcoming Events</h2>
        <div class="calendar-container">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search Events">
                <button type="submit">Search</button>
            </form>

            <div class="event-list">
                <?php
                $events = [
                    ['title' => 'Webinar on AI', 'date' => '2025-02-01', 'location' => 'Online', 'image' => 'event1.jpg'],
                    ['title' => 'Global Conference on Education', 'date' => '2025-03-15', 'location' => 'New York', 'image' => 'event2.jpg'],
                ];

                foreach ($events as $event) {
                    echo "<div class='event'>
                            <img src='{$event['image']}' alt='{$event['title']}' class='gallery-photo'>
                            <h3>{$event['title']}</h3>
                            <p>Date: {$event['date']}</p>
                            <p>Location: {$event['location']}</p>
                            <a href='#' class='button'>Register Now</a>
                          </div>";
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Latest News Section -->
    <section id="news">
        <h2>Latest News</h2>
        <div class="news-container">
            <?php
            $news = [
                ['title' => 'New Scholarship Program Launched', 'summary' => 'We are excited to announce...', 'link' => '#', 'image' => 'news1.jpg'],
                ['title' => 'Partnership with XYZ', 'summary' => 'A new collaboration with XYZ...', 'link' => '#', 'image' => 'news2.jpg']
            ];

            foreach ($news as $item) {
                echo "<div class='news-item'>
                        <img src='{$item['image']}' alt='{$item['title']}' class='gallery-photo'>
                        <h3>{$item['title']}</h3>
                        <p>{$item['summary']}</p>
                        <a href='{$item['link']}' class='button'>Read More</a>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <p>&copy; 2025 College Events & News Hub. All Rights Reserved.</p>
        <nav>
            <a href="#">About</a>
            <a href="#">Contact</a>
            <a href="#">Privacy Policy</a>
        </nav>
    </footer>

</body>
</html>



















<?php
// events_news_page.php

// Start the session and include necessary libraries if needed
session_start();
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Events & News Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* General Styles */
        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #444;
        }

        /* Header */
        header {
            background-color: #ffffff;
            color: #2C3E50;
            text-align: center;
            padding: 40px 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            font-size: 32px;
            font-weight: bold;
        }

        header p {
            font-size: 18px;
            margin-top: 10px;
            color: #7f8c8d;
        }

        nav {
            margin-top: 20px;
        }

        nav a {
            color: #2C3E50;
            text-decoration: none;
            margin: 0 15px;
            font-weight: bold;
            font-size: 16px;
            padding: 10px 20px;
            border-radius: 25px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        nav a:hover {
            background-color: #3498db;
            color: #fff;
        }

        /* Sections */
        section {
            padding: 60px 15%;
            text-align: center;
            background-color: #ffffff;
            margin: 40px 0;
            border-radius: 10px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 30px;
            color: #2C3E50;
            margin-bottom: 30px;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
            font-weight: 600;
        }

        /* Buttons */
        button, a.button {
            background-color: #3498db;
            color: white;
            padding: 12px 20px;
            border: none;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            display: inline-block;
            margin-top: 20px;
        }

        button:hover, a.button:hover {
            background-color: #2980b9;
        }

        /* Event & News Items */
        .event, .news-item {
            background-color: #fff;
            padding: 25px;
            margin: 20px 0;
            border-radius: 10px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            text-align: left;
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: transform 0.3s ease;
        }

        .event:hover, .news-item:hover {
            transform: translateY(-5px);
        }

        .event img, .news-item img {
            width: 100px;
            height: 100px;
            border-radius: 8px;
            margin-right: 20px;
        }

        .event h3, .news-item h3 {
            color: #3498db;
            margin-bottom: 10px;
        }

        .event p, .news-item p {
            font-size: 14px;
            color: #7f8c8d;
            margin-bottom: 10px;
        }

        .news-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Gallery Section */
        .gallery-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .gallery-photo, .gallery-video {
            border-radius: 10px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }

        .gallery-photo {
            width: 280px;
            height: 180px;
            object-fit: cover;
        }

        .gallery-video {
            width: 380px;
            height: 240px;
        }

        /* Social Media */
        .social-feed {
            margin-top: 50px;
            text-align: center;
        }

        .social-feed a {
            margin: 15px;
            font-size: 18px;
            text-decoration: none;
            color: #3498db;
            transition: color 0.3s ease;
        }

        .social-feed a:hover {
            color: #2980b9;
        }

        /* Footer */
        footer {
            background-color: #2C3E50;
            color: white;
            text-align: center;
            padding: 30px;
            font-size: 14px;
            margin-top: 50px;
        }

        footer a {
            color: white;
            text-decoration: none;
            margin: 0 12px;
            font-weight: bold;
        }

    </style>
</head>
<body>

    <!-- Header Section -->
    <header>
        <h1>College Events & News Hub</h1>
        <p>Your go-to platform for the latest college updates and exciting events.</p>
        <nav>
            <a href="#calendar">Upcoming Events</a>
            <a href="#news">Latest News</a>
            <a href="#gallery">Gallery</a>
            <a href="#social">Social Media</a>
        </nav>
    </header>

    <!-- Calendar Section -->
    <section id="calendar">
        <h2>Upcoming Events</h2>
        <form method="GET" action="" style="margin-bottom: 30px;">
            <input type="text" name="search" placeholder="Search Events" style="padding: 10px 15px; font-size: 16px; border-radius: 5px; border: 1px solid #ddd;">
            <button type="submit">Search</button>
        </form>

        <div class="event-list">
            <?php
            $events = [
                ['title' => 'Webinar on AI', 'date' => '2025-02-01', 'location' => 'Online', 'image' => 'event1.jpg'],
                ['title' => 'Global Conference on Education', 'date' => '2025-03-15', 'location' => 'New York', 'image' => 'event2.jpg'],
            ];

            foreach ($events as $event) {
                echo "<div class='event'>
                        <img src='{$event['image']}' alt='{$event['title']}'>
                        <div>
                            <h3>{$event['title']}</h3>
                            <p>Date: {$event['date']}</p>
                            <p>Location: {$event['location']}</p>
                            <a href='#' class='button'>Register Now</a>
                        </div>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Latest News Section -->
    <section id="news">
        <h2>Latest News</h2>
        <div class="news-container">
            <?php
            $news = [
                ['title' => 'New Scholarship Program Launched', 'summary' => 'We are excited to announce...', 'link' => '#', 'image' => 'news1.jpg'],
                ['title' => 'Partnership with XYZ', 'summary' => 'A new collaboration with XYZ...', 'link' => '#', 'image' => 'news2.jpg']
            ];

            foreach ($news as $item) {
                echo "<div class='news-item'>
                        <img src='{$item['image']}' alt='{$item['title']}'>
                        <div>
                            <h3>{$item['title']}</h3>
                            <p>{$item['summary']}</p>
                            <a href='{$item['link']}' class='button'>Read More</a>
                        </div>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <p>&copy; 2025 College Events & News Hub. All Rights Reserved.</p>
        <nav>
            <a href="#">About</a>
            <a href="#">Contact</a>
            <a href="#">Privacy Policy</a>
        </nav>
    </footer>

</body>
</html>















<?php
// events_news_page.php

// Start the session and include necessary libraries if needed
session_start();
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Events & News Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* General Styles */
        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #444;
            background-image: url('background.jpg'); /* Set your background image here */
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }

        /* Header */
        header {
            background-color: rgba(255, 255, 255, 0.85); /* Semi-transparent white */
            color: #2C3E50;
            text-align: center;
            padding: 40px 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px); /* Apply blur effect */
        }

        header h1 {
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        header p {
            font-size: 18px;
            margin-top: 10px;
            color: #7f8c8d;
        }

        nav {
            margin-top: 20px;
        }

        nav a {
            color: #2C3E50;
            text-decoration: none;
            margin: 0 20px;
            font-weight: bold;
            font-size: 16px;
            padding: 12px 20px;
            border-radius: 25px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        nav a:hover {
            background-color: #2ECC71; /* Sea Green */
            color: white;
        }

        /* Sections */
        section {
            padding: 60px 15%;
            text-align: center;
            background-color: #ffffff;
            margin: 40px 0;
            border-radius: 10px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 32px;
            color: #2C3E50;
            margin-bottom: 30px;
            border-bottom: 3px solid #2ECC71; /* Sea Green */
            padding-bottom: 10px;
            font-weight: 600;
        }

        /* Buttons */
        button, a.button {
            background-color: #2ECC71; /* Sea Green */
            color: white;
            padding: 12px 20px;
            border: none;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            display: inline-block;
            margin-top: 20px;
        }

        button:hover, a.button:hover {
            background-color: #27AE60; /* Darker Green */
        }

        /* Event & News Items */
        .event, .news-item {
            background-color: #fff;
            padding: 25px;
            margin: 20px 0;
            border-radius: 10px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            text-align: left;
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: transform 0.3s ease;
        }

        .event:hover, .news-item:hover {
            transform: translateY(-5px);
        }

        .event img, .news-item img {
            width: 100px;
            height: 100px;
            border-radius: 8px;
            margin-right: 20px;
        }

        .event h3, .news-item h3 {
            color: #2ECC71; /* Sea Green */
            margin-bottom: 10px;
        }

        .event p, .news-item p {
            font-size: 14px;
            color: #7f8c8d;
            margin-bottom: 10px;
        }

        .news-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Gallery Section */
        .gallery-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .gallery-photo, .gallery-video {
            border-radius: 10px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }

        .gallery-photo {
            width: 280px;
            height: 180px;
            object-fit: cover;
        }

        .gallery-video {
            width: 380px;
            height: 240px;
        }

        /* Social Media */
        .social-feed {
            margin-top: 50px;
            text-align: center;
        }

        .social-feed a {
            margin: 15px;
            font-size: 18px;
            text-decoration: none;
            color: #2ECC71; /* Sea Green */
            transition: color 0.3s ease;
        }

        .social-feed a:hover {
            color: #27AE60; /* Darker Green */
        }

        /* Footer */
        footer {
            background-color: #2C3E50;
            color: white;
            text-align: center;
            padding: 30px;
            font-size: 14px;
            margin-top: 50px;
        }

        footer a {
            color: white;
            text-decoration: none;
            margin: 0 12px;
            font-weight: bold;
        }

    </style>
</head>
<body>

    <!-- Header Section -->
    <header>
        <h1>College Events & News Hub</h1>
        <p>Your go-to platform for the latest college updates and exciting events.</p>
        <nav>
            <a href="#calendar">Upcoming Events</a>
            <a href="#news">Latest News</a>
            <a href="#gallery">Gallery</a>
            <a href="#social">Social Media</a>
        </nav>
    </header>

    <!-- Calendar Section -->
    <section id="calendar">
        <h2>Upcoming Events</h2>
        <form method="GET" action="" style="margin-bottom: 30px;">
            <input type="text" name="search" placeholder="Search Events" style="padding: 12px 15px; font-size: 16px; border-radius: 5px; border: 1px solid #ddd; width: 80%; margin-bottom: 20px;">
            <button type="submit">Search</button>
        </form>

        <div class="event-list">
            <?php
            $events = [
                ['title' => 'Webinar on AI', 'date' => '2025-02-01', 'location' => 'Online', 'image' => 'event1.jpg'],
                ['title' => 'Global Conference on Education', 'date' => '2025-03-15', 'location' => 'New York', 'image' => 'event2.jpg'],
            ];

            foreach ($events as $event) {
                echo "<div class='event'>
                        <img src='{$event['image']}' alt='{$event['title']}'>
                        <div>
                            <h3>{$event['title']}</h3>
                            <p>Date: {$event['date']}</p>
                            <p>Location: {$event['location']}</p>
                            <a href='#' class='button'>Register Now</a>
                        </div>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Latest News Section -->
    <section id="news">
        <h2>Latest News</h2>
        <div class="news-container">
            <?php
            $news = [
                ['title' => 'New Scholarship Program Launched', 'summary' => 'We are excited to announce...', 'link' => '#', 'image' => 'news1.jpg'],
                ['title' => 'Partnership with XYZ', 'summary' => 'A new collaboration with XYZ...', 'link' => '#', 'image' => 'news2.jpg']
            ];

            foreach ($news as $item) {
                echo "<div class='news-item'>
                        <img src='{$item['image']}' alt='{$item['title']}'>
                        <div>
                            <h3>{$item['title']}</h3>
                            <p>{$item['summary']}</p>
                            <a href='{$item['link']}' class='button'>Read More</a>
                        </div>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <p>&copy; 2025 College Events & News Hub. All Rights Reserved.</p>
        <nav>
            <a href="#">About</a>
            <a href="#">Contact</a>
            <a href="#">Privacy Policy</a>
        </nav>
    </footer>

</body>
</html>
