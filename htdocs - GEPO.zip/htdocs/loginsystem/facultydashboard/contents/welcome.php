

<div id="welcome" class="section">
    <h1>Welcome <?php echo $_SESSION['faculty_id']; ?> </h1>
</div>
