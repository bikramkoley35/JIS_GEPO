<?php
 require '../db_config.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if the file is uploaded correctly
    if (!isset($_FILES['progress-file']) || $_FILES['progress-file']['error'] !== UPLOAD_ERR_OK) {
        echo "No file uploaded or there was an error uploading the file.";
        exit;
    }

    // Retrieve form inputs
    $proposalId = $_POST['proposal-id'] ?? '';
    $reportDate = $_POST['report-date'] ?? '';
    $projectProgress = $_POST['project-progress'] ?? '';
    $challenges = $_POST['challenges'] ?? '';
    $progressFile = $_FILES['progress-file'];

    // Validate form inputs
    if (empty($proposalId) || empty($reportDate) || empty($projectProgress)) {
        echo "All required fields must be filled.";
        exit;
    }

    if (!is_numeric($projectProgress) || $projectProgress < 0 || $projectProgress > 100) {
        echo "Project progress must be a number between 0 and 100.";
        exit;
    }

    // Handle file upload
    $targetDir = "uploads/progress_reports/";
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true); // Create the directory if it doesn't exist
    }

    $targetFile = $targetDir . basename($progressFile["name"]);

    if (move_uploaded_file($progressFile["tmp_name"], $targetFile)) {
        // File upload successful, insert into database
        $stmt = $conn->prepare("INSERT INTO progress_reports (report_date, project_progress, challenges, progress_file_path, proposal_id) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sisss", $reportDate, $projectProgress, $challenges, $targetFile, $proposalId);

        if ($stmt->execute()) {
            echo "<script>alert('Progress report submitted successfully and recorded in the database.');
                    window.location.href = '../index.php?section=welcome';
                    </script>";
            
        } else {
            echo "<script>alert('Error inserting record .$stmt->error;');
                    window.location.href = '../index.php?section=welcome';
                    </script>";
           
        }

        $stmt->close();
    } else {
        
        echo "<script>alert('Sorry, there was an error uploading your file.');
        window.location.href = '../index.php?section=progress_report';
        </script>";
    }
}
// Include database connection
//require_once 'db_connection.php'; // Adjust the path to your actual connection file

// if ($_SERVER['REQUEST_METHOD'] == 'POST') {
//     // Check if proposal_id is set in the POST request
//     if (isset($_POST['proposal_id'])) {
//         // Get form data
//         $proposal_id = $_POST['proposal_id']; // Project proposal ID
//         $project_progress = $_POST['project_progress']; // New progress percentage
//         $challenges = $_POST['challenges']; // Challenges text
//         $submission_date = date('Y-m-d H:i:s'); // Current timestamp

//         // Initialize $file_path to avoid undefined variable error
//         $file_path = '';

//         // Check if a new file is uploaded
//         if (isset($_FILES['progress_file']) && $_FILES['progress_file']['error'] == 0) {
//             // Handle file upload
//             $upload_dir = 'uploads/'; // Directory where files will be uploaded
//             $file_name = basename($_FILES['progress_file']['name']);
//             $file_path = $upload_dir . $file_name;

//             // Move the uploaded file to the specified directory
//             if (move_uploaded_file($_FILES['progress_file']['tmp_name'], $file_path)) {
//                 echo "File uploaded successfully.<br>";
//             } else {
//                 echo "Error uploading the file.<br>";
//             }
//         } else {
//             // If no new file, get the current file path from the database
//             $file_path = getCurrentFilePathByProposalId($proposal_id, $conn);
//         }

//         // Update the progress report in the database
//         $sql = "UPDATE progress_reports
//                 SET project_progress = ?, progress_file_path = ?, submission_date = ?
//                 WHERE proposal_id = ?";

//         if ($stmt = $conn->prepare($sql)) {
//             $stmt->bind_param("issi", $project_progress, $file_path, $submission_date, $proposal_id);
//             if ($stmt->execute()) {
//                 echo "Progress report updated successfully!";
//             } else {
//                 echo "Error updating progress report: " . $stmt->error;
//             }
//             $stmt->close();
//         } else {
//             echo "Error preparing the SQL statement: " . $conn->error;
//         }
//     } else {
//         // Handle the case where proposal_id is not set
//         echo "Proposal ID is missing. Please provide a valid Proposal ID.<br>";
//     }
// }

// // Function to get the current file path for a report using proposal_id (if no new file is uploaded)
// function getCurrentFilePathByProposalId($proposal_id, $conn) {
//     $sql = "SELECT progress_file_path FROM progress_reports WHERE proposal_id = ?";
//     $current_file_path = ''; // Define variable before use
//     if ($stmt = $conn->prepare($sql)) {
//         $stmt->bind_param("i", $proposal_id);
//         $stmt->execute();
//         $stmt->bind_result($current_file_path);
//         if ($stmt->fetch()) {
//             // Return the existing file path if found
//             $stmt->close();
//             return $current_file_path;
//         } else {
//             // Handle case where no file path is found
//             echo "No previous file path found for this proposal ID.<br>";
//             $stmt->close();
//             return ''; // Return empty string if no file is found
//         }
//     } else {
//         echo "Error retrieving current file path: " . $conn->error . "<br>";
//         return ''; // Return empty string in case of error
//     }
// }
?>
