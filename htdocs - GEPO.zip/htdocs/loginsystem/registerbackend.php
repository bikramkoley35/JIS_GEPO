<?php
session_start();
require 'db_config.php';


error_reporting(E_ALL);
ini_set('display_errors', 1);


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include Composer's autoload file for PHPMailer
require 'vendor/autoload.php';

// Function to send the email
function sendRegistrationEmail($email, $faculty_id, $password) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'supriyojanaa@gmail.com';
        $mail->Password = 'udkzgwyqbxuduwut';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('supriyojanaa@gmail.com', 'Registration Mail'); // Replace with your sender email/name
        $mail->addAddress($email);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Registration Details';
        $mail->Body = "
            <h1>Registration Successful</h1>
            <p>Your registration was successful. Here are your details:</p>
            <ul>
                <li><strong>ID:</strong> $faculty_id</li>
                <li><strong>Password:</strong> $password</li>
            </ul>
            <p>Thank you for registering!</p>
        ";

        $mail->send();
        echo "<script>alert('Registration successful! Details sent to your email.'); window.location.href='loginindex.php';</script>";
    } catch (Exception $e) {
        echo "<script>alert('Registration successful, but email could not be sent.');</script>";
    }
}

function sendpartnerEmail($email, $partner_id, $password) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'supriyojanaa@gmail.com';
        $mail->Password = 'udkzgwyqbxuduwut';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('supriyojanaa@gmail.com', 'Registration Mail'); // Replace with your sender email/name
        $mail->addAddress($email);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Registration Details';
        $mail->Body = "
            <h1>Registration Successful</h1>
            <p>Your registration was successful. Here are your details:</p>
            <ul>
                <li><strong>ID:</strong> $partner_id</li>
                <li><strong>Password:</strong> $password</li>
            </ul>
            <p>Thank you for registering!</p>
        ";

        $mail->send();
        echo "<script>alert('Registration successful! Details sent to your email.'); window.location.href='loginindex.php';</script>";
    } catch (Exception $e) {
        echo "<script>alert('Registration successful, but email could not be sent.');</script>";
    }
}
// Inside the faculty registration section



function isCollegeCodeValid($conn, $college_code) {
    $query = "SELECT COUNT(*) AS count FROM partner_colleges WHERE Code = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $college_code);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['count'] > 0;
}

// Helper function to generate faculty_id
function generateFacultyId($conn, $college_code) {
    $currentYear = date("Y");
    $tableName = "{$college_code}_faculty";

    $query = "SELECT faculty_id FROM $tableName ORDER BY created_at DESC LIMIT 1";
    $result = $conn->query($query);

    $nextId = 1;
    if ($result && $row = $result->fetch_assoc()) {
        $lastId = $row['faculty_id'];
        $lastNumber = intval(substr($lastId, -4));
        $nextId = $lastNumber + 1;
    }

    return sprintf("%s/%s/%04d", strtolower($college_code), $currentYear, $nextId);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo '<pre>';
    print_r($_POST);
    echo '</pre>';
    $role = $_POST['role'];


    if ($role !== 'partner' && $role !== 'faculty') {
        echo "<script>alert('Invalid role selected.'); window.history.back();</script>";
        exit;
    }

    if ($role === 'faculty') {
        $email = strtolower($_POST['email']); // Convert to lowercase
        $full_name = $_POST['full_name'];
        $dept = strtolower($_POST['dept']); // Convert to lowercase
        $pass = $_POST['pass'];
        $created_at = date("Y-m-d H:i:s");
        $college_code = strtolower($_POST['college_code']); // Convert to lowercase

        if (!isCollegeCodeValid($conn, $college_code)) {
            echo "<script>alert('Invalid college code. Please try again.');</script>";
        }
        // createFacultyTable($conn, $college_code);

        $faculty_id = generateFacultyId($conn, $college_code);
        $tableName = "{$college_code}_faculty";

        $query = "INSERT INTO $tableName (faculty_id, email, full_name, dept, pass, created_at)
                  VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssss", $faculty_id, $email, $full_name, $dept, $pass, $created_at);
        if ($stmt->execute()) {
            // Faculty successfully registered
            $faculty_id = generateFacultyId($conn,$college_code); // Replace with the function generating faculty_id
            $password = $_POST['pass'];
            // Send email
            sendRegistrationEmail($email, $faculty_id, $password);
            // echo "<script>alert('Faculty registered successfully with ID: $faculty_id'); window.location.href='loginindex.php';</script>";
            
        } else {
            echo "<script>alert('Error: {$stmt->error}'); window.history.back();</script>";
        }
        $stmt->close();
    // Inside the principal section
    } elseif ($role === 'partner') {


        $name = trim($_POST['name']);
        $email = $_POST['email'];
        $password = $_POST['pass'];
        $institution = $_POST['institution'];
        $country = $_POST['country'];

        // Split Name and Extract Initials
        $name_parts = explode(" ", $name);
        $first_initial = strtoupper(substr($name_parts[0], 0, 1)); // First letter of first name
        $last_initial = strtoupper(substr(end($name_parts), 0, 1)); // First letter of last name

        // Generate Unique Partner ID (Format: FLYYYYMMDDHHMMSSXXX)
        $timestamp = date("YmdHis"); // Current Timestamp
        $random_num = rand(100, 999); // 3 Random Digits
        $partner_id = $first_initial . $last_initial . $timestamp . $random_num;

        // Insert into database
        $sql = "INSERT INTO partners (partner_id, name, email, password, institution, country) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $partner_id, $name, $email, $password, $institution, $country);

        if ($stmt->execute()) {
            $_SESSION["partner_id"] = $partner_id;
            sendpartnerEmail($email, $partner_id, $password); // Store ID in session
            //header("Location: partner_dashboard.php");
            exit();
        } else {
            echo "<script>alert('Error: {$stmt->error}'); window.history.back();</script>";
        }


}

}


$conn->close();
?>
