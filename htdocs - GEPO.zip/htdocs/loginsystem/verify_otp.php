<?php
session_start();
var_dump($_SESSION); // Debugging session storage


// Secure headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline';");



if (!isset($_SESSION['OTP'])) {
    die("Session expired. Please request a new OTP.");
}

// Debugging: Check if OTP is stored in the session
var_dump($_SESSION['OTP']); 





// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_otp = $_POST['otp'];
    
    if (!isset($_SESSION['OTP']) || !$user_otp) {
        header('Location: loginindex.php?error=missing_otp');
        exit();
    }

    //Validate OTP
    if ($user_otp == $_SESSION['OTP']) {
        // OTP is valid
        unset($_SESSION['OTP']); // Invalidate the OTP after use

        // Redirect based on user role
       
        if ($_SESSION['role'] === 'faculty'){
         
            $_SESSION['user_logged_in'] = true;
            header('Location: facultydashboard/index.php');
        } elseif ($_SESSION['role'] === 'administrator') {
            $_SESSION['user_logged_in'] = true;
            header('Location: admindashboard/index.php');
        } elseif ($_SESSION['role'] === 'partner') {
            $_SESSION['user_logged_in'] = true;
            header('Location: partnersdashboard/index.php');
        } else {
            header('Location: loginindex.php?error=unknown_role');
        }
        exit();
    } else {
        // Invalid OTP
        header('Location: loginindex.php?error=invalid_otp');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .otp-container {
            background: #ffffff;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 90%;
            max-width: 400px;
        }
        .otp-container h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .otp-container input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }
        .otp-container button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .otp-container button:hover {
            background-color: #0056b3;
        }
        .error-message {
            color: red;
            margin-bottom: 10px;
        }
        @media (max-width: 480px) {
            .otp-container {
                padding: 15px;
            }
            .otp-container h2 {
                font-size: 24px;
            }
            .otp-container button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="otp-container">
        <h2>OTP Verification</h2>
        <?php if (isset($_GET['error'])): ?>
            <p class="error-message">
                <?php echo htmlspecialchars($_GET['error']); ?>
            </p>
        <?php endif; ?>
        <form method="POST" action="">
            <label for="otp">Enter the OTP sent to your email:</label>
            <input type="text" id="otp" name="otp" placeholder="6-digit OTP" required>
            <button type="submit">Verify OTP</button>
        </form>
    </div>
</body>
</html>
