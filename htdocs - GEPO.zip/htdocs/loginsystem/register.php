

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 500px;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #28a745;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background-color: #218838;
        }

        .error {
            color: red;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Register</h1>
        <form id="registerForm" action="registerbackend.php" method="POST">
            <label for="role">Role:</label>
            <select id="role" name="role" required>
                <option value="" disabled selected>Select Role</option>
                <option value="faculty">Faculty</option>
                <option value="partner">Partner</option>
            </select>


           <!-- Faculty fields -->
<div id="faculty-fields" style="display:none;">
    <label for="college_code">College Code:</label>
    <input type="text" id="college_code" name="college_code">

    <label for="email">Email:</label>
    <input type="email" id="email" name="email">

    <label for="full_name">Full Name:</label>
    <input type="text" id="full_name" name="full_name">

    <label for="dept">Department:</label>
    <input type="text" id="dept" name="dept">
</div>

<!-- Partner fields -->
<div id="partner-fields" style="display:none;">
    <label for="name">Name:</label>
    <input type="text" name="name">

    <label for="email">Email:</label>
    <input type="email" name="email">

    <label for="institution">Institution:</label>
    <input type="text" name="institution">

    <label for="country">Country:</label>
    <input type="text" name="country">
</div>


            
            <label for="pass">Password:</label>
            <input type="password" id="pass" name="pass" required>

            <label for="confirm_pass">Confirm Password:</label>
            <input type="password" id="confirm_pass" name="confirm_pass" required>

            <button type="submit">Register</button>
            <p id="passwordError" class="error" style="display:none;">Passwords do not match!</p>
        </form>
    </div>

    <script>
        const roleSelect = document.getElementById('role');
const facultyFields = document.getElementById('faculty-fields');
const partnerFields = document.getElementById('partner-fields');

// Function to enable or disable hidden fields
function toggleFields() {
    if (roleSelect.value === 'faculty') {
        facultyFields.style.display = 'block';
        partnerFields.style.display = 'none';

        // Enable faculty fields, disable partner fields
        document.querySelectorAll('#faculty-fields input').forEach(input => {
            input.disabled = false;
            input.required = true;
        });
        document.querySelectorAll('#partner-fields input').forEach(input => {
            input.disabled = true;
            input.required = false;
        });

    } else if (roleSelect.value === 'partner') {
        facultyFields.style.display = 'none';
        partnerFields.style.display = 'block';

        // Enable partner fields, disable faculty fields
        document.querySelectorAll('#partner-fields input').forEach(input => {
            input.disabled = false;
            input.required = true;
        });
        document.querySelectorAll('#faculty-fields input').forEach(input => {
            input.disabled = true;
            input.required = false;
        });
    }
}

// Run function when the role changes
roleSelect.addEventListener('change', toggleFields);

// Run it once on page load to ensure correct state
toggleFields();

        
        document.getElementById('role').addEventListener('change', function () {
    const facultyFields = document.getElementById('faculty-fields');
    const partnerFields = document.getElementById('partner-fields');

    if (this.value === 'faculty') {
        facultyFields.style.display = 'block';
        partnerFields.style.display = 'none';
    } else if (this.value === 'partner') {
        facultyFields.style.display = 'none';
        partnerFields.style.display = 'block';
    }
});




document.getElementById('registerForm').addEventListener('submit', function (e) {
    const pass = document.getElementById('pass').value;
    const confirmPass = document.getElementById('confirm_pass').value;
    const role = document.getElementById('role').value;

    if (pass !== confirmPass) {
        e.preventDefault();
        document.getElementById('passwordError').style.display = 'block';
        document.getElementById('passwordError').textContent = 'Passwords do not match!';
    } else {
        document.getElementById('passwordError').style.display = 'none';
    }
});


    </script>
</body>
</html>