<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "test");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all inquiries
$sql = "SELECT * FROM partnership_inquiries ORDER BY submitted_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Manage Inquiries</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid black; padding: 10px; text-align: left; }
        th { background-color: #f2f2f2; }
        .status-btn { padding: 5px 10px; margin: 2px; cursor: pointer; border: none; }
        .in-progress { background-color: orange; color: white; }
        .accepted { background-color: green; color: white; }
        .rejected { background-color: red; color: white; }
    </style>
</head>
<body>
    <h2>Admin - Manage Partnership Inquiries</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Institution</th>
            <th>Country</th>
            <th>Address</th>
            <th>Message</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr id="row-<?php echo $row['id']; ?>">
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['institution']; ?></td>
            <td><?php echo $row['country']; ?></td>
            <td><?php echo $row['address']; ?></td>
            <td><?php echo $row['message']; ?></td>
            <td id="status-<?php echo $row['id']; ?>"><?php echo $row['status']; ?></td>
            <td>
                <button class="status-btn in-progress" onclick="updateStatus(<?php echo $row['id']; ?>, 'In Progress')">In Progress</button>
                <button class="status-btn accepted" onclick="updateStatus(<?php echo $row['id']; ?>, 'Accepted')">Accept</button>
                <button class="status-btn rejected" onclick="updateStatus(<?php echo $row['id']; ?>, 'Rejected')">Reject</button>
            </td>
        </tr>
        <?php } ?>
    </table>

    <script>
        function updateStatus(id, status) {
            $.ajax({
                url: "update_inquirystatus.php",
                type: "POST",
                data: { id: id, status: status },
                success: function(response) {
                    $("#status-" + id).text(status);
                    alert("Status updated successfully!");
                },
                error: function() {
                    alert("Error updating status.");
                }
            });
        }
    </script>
</body>
</html>

<?php $conn->close(); ?>
